import React, { Component } from 'react'
import './createCSS.css'
import './background.css'

class Delete extends Component {
 
    render() {

        return (
            
            <div className="process_container">

                <h1> Delete successful! </h1>

            </div>

        );

    }
}

export default Delete