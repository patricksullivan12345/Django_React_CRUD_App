from django.contrib import admin
from CRUD.models import Text_fields

# Register your models here.
admin.site.register(Text_fields)
